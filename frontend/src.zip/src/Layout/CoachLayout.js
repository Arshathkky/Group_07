import React from 'react'

const CoachLayout = () => {
  return (
    <div>
      <h1>HI</h1>
    </div>
  )
}

export default CoachLayout
