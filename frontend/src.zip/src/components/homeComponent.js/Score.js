import React from 'react'

const Score = () => {
  return (
    <div>
      Score
    </div>
  )
}

export default Score
