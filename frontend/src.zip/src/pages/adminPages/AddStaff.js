import React from 'react'

const AddStaff = () => {
  return (
    <div className='adminContainer'>
      AddStaff
    </div>
  )
}

export default AddStaff
