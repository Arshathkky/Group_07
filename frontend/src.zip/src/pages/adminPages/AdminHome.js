import React from 'react'



const AdminHome = () => {
  return (
    <div >
        
      <h1 className='home'>Welcome to the Admin Page</h1>

    </div>
  )
}

export default AdminHome
