import React from 'react'

const AddScore = () => {
  return (
    <div className='adminContainer'>
      AddScore
    </div>
  )
}

export default AddScore
