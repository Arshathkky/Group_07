import React, { useState, useEffect } from "react";
import { AiFillPlusCircle } from "react-icons/ai";
import axios from "axios";


const AddGallery = () => {
  const [photos, setPhotos] = useState([]);
  const [updateUI, setUpdateUI] = useState("");

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/get")
      .then((res) => {
        console.log(res.data);
        setPhotos(res.data);
      })
      .catch((err) => console.log(err));
  }, [updateUI]);

  

  const handleChange = (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append("photo", e.target.files[0]);

    axios
      .post("http://localhost:5000/api/save", formData)
      .then((res) => {
        console.log(res.data);
        setUpdateUI(res.data._id);
      })
      .catch((err) => console.log(err));
  };

  return (
    <div className='adminContainer '>
      <h1>Our Gallery</h1>
      <div className="grid">
        {photos.map(({ photo, _id }) => (
          <div key={_id} className="grid__item">
            <img src={`http://localhost:5000/uploads/${photo}`} alt="grid_image" />
            
          </div>
        ))}
      </div>

      <label htmlFor="file_picker" className="galleryButton">
        <AiFillPlusCircle />
        <input
          hidden
          type="file"
          name="file_picker"
          id="file_picker"
          onChange={(e) => handleChange(e)}
        />
      </label>
    </div>
  );
};

export default AddGallery;