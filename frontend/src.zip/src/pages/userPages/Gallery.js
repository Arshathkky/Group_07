import React from "react";
import { useEffect, useState } from "react";
import ImageUploads from "../adminPages/AddGallery"

import axios from "axios";
const Gallery = () => {
  const [photos, setPhotos] = useState([]);
  const [updateUI,setUpdateUI] = useState("");

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/get")
      .then((res) => {
        console.log(res.data);
        setPhotos(res.data);
      })
      .catch((err) => console.log(err));
  }, [updateUI]);

  return (
    <>
      <h1>Our Gallery</h1>
      <div className="grid">
        {photos.map(({ photo, _id }) => (
          <div key={_id} className="grid__item">
            <img src={`http://localhost:5000/uploads/${photo}`} alt="grid_image" />
            
          </div>
        ))}
      </div>

    </>
  );
};

export default Gallery;